// config.js

module.exports = {
    development: {
      username: 'root',
      password: '',
      database: 'incasadb',
      host: 'localhost',
      dialect: 'mysql'
    },
    // Outros ambientes, como produção e teste, podem ser configurados aqui
  };
  