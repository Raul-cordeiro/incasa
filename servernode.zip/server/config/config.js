// config.js

module.exports = {
    development: {
      username: 'sql_incasaimovei',
      password: 'KL85CEJhPeZJsCkr',
      database: 'sql_incasaimovei',
      host: 'localhost',
      dialect: 'mysql'
    },
    // Outros ambientes, como produção e teste, podem ser configurados aqui
  };
  